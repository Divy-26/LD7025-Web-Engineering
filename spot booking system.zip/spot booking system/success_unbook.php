<!DOCTYPE html>
<head>
<title>Successful unbooking</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('include/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('include/header.php');
						
	?>
	
	<section id="content">
	<img src="parking.svg" style="position:absolute; z-index:-1; margin:0;"/>
	<p class="phead">Unbooking of Parking Slot Successful</p>
	</section>
	</section>
	
</body>
</html>