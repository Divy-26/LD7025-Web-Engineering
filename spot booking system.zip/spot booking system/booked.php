<!DOCTYPE html>
<head>
<title>Vehicle Park Management System</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('include/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('include/header.php');
						
	?>
	
	<section id="content">
	<p class="phead">You have already booked a parking lot</p>
	</section>
	</section>
	
</body>
</html>