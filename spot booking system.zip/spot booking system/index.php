<!DOCTYPE html>
<head>
<title>Main Home Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('include/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('include/header.php');
						
	?>
<!-- Logo Section -->
<header>
    <div class="logo-container" style="display: flex; align-items: center; margin: 10px;">
        <img src="logo.png" alt="BookMySpot Logo" style="width: 80px; height: auto; margin-right: 15px;">
        <h1 style="font-family: Arial, sans-serif; color: #333; margin: 0;">BookMySpot</h1>
    </div>
</header>



	<section id="content">
	<div>
		<vhead>Welcome To Book My Spot </br></vhead>
	</div>
	<!-- Image Section -->
<div style="text-align: center; margin-top: 20px;">
    <img src="parking.jpg" alt="Parking Image" style="width: 600px; height: auto;">
</div>

	</section>
	</section>
	
</body>
</html>