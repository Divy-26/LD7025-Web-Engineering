<!DOCTYPE html>
<head>
<title>Transaction</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('include/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('include/header.php');
						
	?>
	
	<section id="content">
	<img src="parking.svg" style="position:absolute; z-index:-1; margin:0;"/>
	<div>
		<p class="phead">Pay Parking Fees</p>
		<section class="parking">
			<ol>
				<li>Select Pay Bill</li>
				<li>Enter Business no:</li>
				<li>Enter your phone no as the account number</li>
				<li>Enter amount Rs 60 per hour</li>
				<li>Enter your pin no and confirm</li>
				<li>Click on Finish to complete your booking.</li>
			
			</ol>
			<a href="success.php" >Finish </a>
		</section>
	</div>
	
	</section>
	</section>
	
</body>
</html>