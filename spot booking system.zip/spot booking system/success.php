<!DOCTYPE html>
<head>
<title>Successful Payment</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<?php
			include('include/head.php');
	?>
</head>
<body>
	<section id="container">
	<?php
			include('include/header.php');
						
	?>
	
	<section id="content">
	<div>
		<vhead>Booking Successful</vhead>
	</div>
	<p style="margin:auto;text-align:center;font-weight:bold;">Request submitted successfully.</p>
	
	</section>
	</section>
</body>
</html>