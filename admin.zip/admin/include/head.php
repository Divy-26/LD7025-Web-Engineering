<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
     
<link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
<link rel="stylesheet" href="styles/styles.css" type="text/css" />
<link rel="stylesheet" href="styles/pager.css" type="text/css" />
<script src="js/jquery.js"></script>
<script src="js/myjs.js"></script>

 

<script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>